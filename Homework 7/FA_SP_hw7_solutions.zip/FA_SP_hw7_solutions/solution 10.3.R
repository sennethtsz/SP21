# -------------------- Code for Question 10.3 -----------------------------

# Clear environment

rm(list=ls())

# Set the working directory


# Read the data file

gcdat<-read.table("GT_IAM/data/germancredit.txt",sep = " ")

#
# Optional check to make sure the data is read correctly
#

head(gcdat)

##    V1 V2  V3  V4   V5  V6  V7 V8  V9  V10 V11  V12 V13  V14  V15 V16  V17 V18  V19  V20 V21
## 1 A11  6 A34 A43 1169 A65 A75  4 A93 A101   4 A121  67 A143 A152   2 A173   1 A192 A201   1
## 2 A12 48 A32 A43 5951 A61 A73  2 A92 A101   2 A121  22 A143 A152   1 A173   1 A191 A201   2
## 3 A14 12 A34 A46 2096 A61 A74  2 A93 A101   3 A121  49 A143 A152   1 A172   2 A191 A201   1
## 4 A11 42 A32 A42 7882 A61 A74  2 A93 A103   4 A122  45 A143 A153   1 A173   2 A191 A201   1
## 5 A11 24 A33 A40 4870 A61 A73  3 A93 A101   4 A124  53 A143 A153   2 A173   2 A191 A201   2
## 6 A14 36 A32 A46 9055 A65 A73  2 A93 A101   4 A124  35 A143 A153   1 A172   2 A192 A201   1


# Since binomial family of glm recognises 0 and 1 as the classfication values, 
# convert 1s and 2s to 0s and 1s for the response variable

gcdat$V21[gcdat$V21==1]<-0
gcdat$V21[gcdat$V21==2]<-1

# Set the seed to produce reproducible results as random sampling is done in 
#the next step

set.seed(1)

# Divide the data into 70% training and 30% test/validation data

m <- nrow(gcdat)
trn <- sample(1:m, size = round(m*0.7), replace = FALSE)
d.learn <- gcdat[trn,]
d.valid <- gcdat[-trn,]

# Develop the logistic regression model

# 1st iteration: Use all the available variables

reg = glm(V21 ~.,family=binomial(link = "logit"),data=d.learn)
summary(reg)

# 2nd iteration: Use all the variables found significant in 
# the 1st iteration.
# For categorical variables, if any value is significant,
# we'll keep all values in the model.

reg = glm(V21 ~ V1+V2+V3+V4+V5+V6+V7+V8+V9+V10+V12+V14+V16+V20,family=binomial(link = "logit"),data=d.learn)
summary(reg)

# V1, V2, V3, V4, V5, V6, V8, V9, V10, V14, V20 are significant.

# 3rd iteration: Use only the significant variables obtained in the 2nd iteration.

reg = glm(V21 ~ V1+V2+V3+V4+V5+V6+V8+V9+V10+V14+V20,family=binomial(link = "logit"),data=d.learn)
summary(reg)

# But for the categorical variables, not all values are significant.
# So, we can create a binary variable for each
# significant factor:

d.learn$V1A13[d.learn$V1 == "A13"] <- 1
d.learn$V1A13[d.learn$V1 != "A13"] <- 0

d.learn$V1A14[d.learn$V1 == "A14"] <- 1
d.learn$V1A14[d.learn$V1 != "A14"] <- 0

d.learn$V3A32[d.learn$V3 == "A32"] <- 1
d.learn$V3A32[d.learn$V3 != "A32"] <- 0

d.learn$V3A33[d.learn$V3 == "A33"] <- 1
d.learn$V3A33[d.learn$V3 != "A33"] <- 0

d.learn$V3A34[d.learn$V3 == "A34"] <- 1
d.learn$V3A34[d.learn$V3 != "A34"] <- 0

d.learn$V4A41[d.learn$V4 == "A41"] <- 1
d.learn$V4A41[d.learn$V4 != "A41"] <- 0

d.learn$V4A410[d.learn$V4 == "A410"] <- 1
d.learn$V4A410[d.learn$V4 != "A410"] <- 0

d.learn$V4A42[d.learn$V4 == "A42"] <- 1
d.learn$V4A42[d.learn$V4 != "A42"] <- 0

d.learn$V4A43[d.learn$V4 == "A43"] <- 1
d.learn$V4A43[d.learn$V4 != "A43"] <- 0

d.learn$V4A48[d.learn$V4 == "A48"] <- 1
d.learn$V4A48[d.learn$V4 != "A48"] <- 0

d.learn$V4A49[d.learn$V4 == "A49"] <- 1
d.learn$V4A49[d.learn$V4 != "A49"] <- 0

d.learn$V6A63[d.learn$V6 == "A63"] <- 1
d.learn$V6A63[d.learn$V6 != "A63"] <- 0

d.learn$V6A65[d.learn$V6 == "A65"] <- 1
d.learn$V6A65[d.learn$V6 != "A65"] <- 0

d.learn$V9A93[d.learn$V9 == "A93"] <- 1
d.learn$V9A93[d.learn$V9 != "A93"] <- 0

d.learn$V10A103[d.learn$V10 == "A103"] <- 1
d.learn$V10A103[d.learn$V10 != "A103"] <- 0

d.learn$V14A143[d.learn$V14 == "A143"] <- 1
d.learn$V14A143[d.learn$V14 != "A143"] <- 0

d.learn$V20A202[d.learn$V20 == "A202"] <- 1
d.learn$V20A202[d.learn$V20 != "A202"] <- 0

# Next round model:

reg = glm(V21 ~ V1A13 + V1A14 + V2 + V3A32 + V3A33 + V3A34 + V4A41 + V4A410 + V4A42 + V4A43 + V4A48 + V4A49 + V5 + V6A63 + V6A65 + V8 + V9A93 + V10A103 + V14A143 + V20A202,family=binomial(link = "logit"),data=d.learn)
summary(reg)

# Remove V4A48 and V6A63 (p-value above 0.05) and V20A202 (p-value above 0.1)

reg = glm(V21 ~ V1A13 + V1A14 + V2 + V3A32 + V3A33 + V3A34 + V4A41 + V4A410 + V4A42 + V4A43 + V4A49 + V5 + V6A65 + V8 + V9A93 + V10A103 + V14A143,family=binomial(link = "logit"),data=d.learn)
summary(reg)

## Coefficients:
##              Estimate Std. Error z value Pr(>|z|)    
## (Intercept)  2.93e-01   5.04e-01    0.58  0.56052    
## V1A13       -1.47e+00   4.88e-01   -3.01  0.00261 ** 
## V1A14       -1.53e+00   2.38e-01   -6.43  1.3e-10 ***
## V2           3.34e-02   1.04e-02    3.22  0.00128 ** 
## V3A32       -6.58e-01   3.36e-01   -1.96  0.04989 *  
## V3A33       -8.60e-01   4.21e-01   -2.04  0.04123 *  
## V3A34       -1.44e+00   3.79e-01   -3.79  0.00015 ***
## V4A41       -1.99e+00   4.63e-01   -4.31  1.7e-05 ***
## V4A410      -2.82e+00   1.07e+00   -2.64  0.00834 ** 
## V4A42       -6.77e-01   2.76e-01   -2.45  0.01429 *  
## V4A43       -7.93e-01   2.61e-01   -3.04  0.00237 ** 
## V4A49       -7.88e-01   3.65e-01   -2.16  0.03100 *  
## V5           1.25e-04   5.05e-05    2.47  0.01342 *  
## V6A65       -1.14e+00   3.10e-01   -3.67  0.00025 ***
## V8           2.64e-01   1.02e-01    2.58  0.00987 ** 
## V9A93       -6.28e-01   2.08e-01   -3.02  0.00250 ** 
## V10A103     -1.15e+00   4.84e-01   -2.38  0.01735 *  
## V14A143     -7.70e-01   2.45e-01   -3.15  0.00164 ** 
## ---
## Signif. codes:  0 �***� 0.001 �**� 0.01 �*� 0.05 �.� 0.1 � � 1
## 
## AIC: 673.5

#The coefficients of each significant factor are shown above in the "estimate" column.


# -------- Validation -------- #

# Now add the binary variables to the validation set

d.valid$V1A13[d.valid$V1 == "A13"] <- 1
d.valid$V1A13[d.valid$V1 != "A13"] <- 0

d.valid$V1A14[d.valid$V1 == "A14"] <- 1
d.valid$V1A14[d.valid$V1 != "A14"] <- 0

d.valid$V3A32[d.valid$V3 == "A32"] <- 1
d.valid$V3A32[d.valid$V3 != "A32"] <- 0

d.valid$V3A33[d.valid$V3 == "A33"] <- 1
d.valid$V3A33[d.valid$V3 != "A33"] <- 0

d.valid$V3A34[d.valid$V3 == "A34"] <- 1
d.valid$V3A34[d.valid$V3 != "A34"] <- 0

d.valid$V4A41[d.valid$V4 == "A41"] <- 1
d.valid$V4A41[d.valid$V4 != "A41"] <- 0

d.valid$V4A410[d.valid$V4 == "A410"] <- 1
d.valid$V4A410[d.valid$V4 != "A410"] <- 0

d.valid$V4A42[d.valid$V4 == "A42"] <- 1
d.valid$V4A42[d.valid$V4 != "A42"] <- 0

d.valid$V4A43[d.valid$V4 == "A43"] <- 1
d.valid$V4A43[d.valid$V4 != "A43"] <- 0

d.valid$V4A49[d.valid$V4 == "A49"] <- 1
d.valid$V4A49[d.valid$V4 != "A49"] <- 0

d.valid$V6A65[d.valid$V6 == "A65"] <- 1
d.valid$V6A65[d.valid$V6 != "A65"] <- 0

d.valid$V9A93[d.valid$V9 == "A93"] <- 1
d.valid$V9A93[d.valid$V9 != "A93"] <- 0

d.valid$V10A103[d.valid$V10 == "A103"] <- 1
d.valid$V10A103[d.valid$V10 != "A103"] <- 0

d.valid$V14A143[d.valid$V14 == "A143"] <- 1
d.valid$V14A143[d.valid$V14 != "A143"] <- 0

# test the model

y_hat<-predict(reg,d.valid,type = "response")
y_hat

# y_hat is a vector of fractions.
# Now we can use a threshold to make yes/no decisions,
# and view the confusion matrix.

y_hat_round <- as.integer(y_hat > 0.5)

t <- table(y_hat_round,d.valid$V21)
t

# Model's accuracy is (183 + 45) / (183 + 45 + 25 + 47) = 76%.

acc <- (t[1,1] + t[2,2]) / sum(t)
acc
## [1] 0.76

# Before exploring more thresholds, let's examine the potential of the model
# using the ROC:

# Version 1 - code from scratch
# get unique threshold values from the predicted values
thr=sort(unique(c(y_hat,0,1)), decreasing=TRUE)

# set up variables for ROC and AUC
n = length(y_hat)
y = d.valid$V21
pos = length(y[y==1])  # number of positive values
neg = length(y[y==0])  # number of negative values
auc=0
last_tpr = 0
last_tnr = 1
# data frame to store results
res.df = data.frame(Thr=double(), TNR=double(), TPR=double(), Acc=double()) #, AUC=double(), ltnr=double(), ltpr=double())

# capture TNR, TPR, Accuracy, AUC contribution at each threshold from predicted values
for (i in thr){
    y_hat_round <- as.integer(y_hat > i) 
    acc = sum(y==y_hat_round)/n
    tp = sum(y[y==1]==y_hat_round[y==1])
    tn = sum(y[y==0]==y_hat_round[y==0])
    tpr = tp / pos
    tnr = tn / neg
    # calc AUC contribution
    if (i<1){
        auc = auc + (last_tpr*(last_tnr - tnr))
    }
    df = data.frame(Thr=i, TNR=tnr, TPR=tpr, Acc=acc) #, AUC=auc, ltnr=last_tnr, ltpr=last_tpr)
    res.df = rbind(res.df, df)
    last_tpr = tpr
    last_tnr = tnr
}
# plot ROC
plot(res.df$TNR, res.df$TPR, type='l', xlim=c(1.002,0), ylim=c(0,1.002), 
     yaxs="i", xaxs="i", col='blue', ylab='Sensitivity (TPR)', xlab='Specificity (TNR)', main='ROC curve')
abline(1,-1, col='gray')
legend('center', legend=paste('AUC = ',round(auc,4)), bty='n')

# show sample from table metrics at each threshold 
res.df[seq(2,302,20),]
##        Thr    TNR   TPR   Acc
## 2   0.9253 1.0000 0.000 0.693
## 22  0.6967 0.9904 0.196 0.747
## 42  0.6145 0.9615 0.348 0.773
## 62  0.5516 0.9135 0.457 0.773
## 82  0.4686 0.8510 0.533 0.753
## 102 0.3774 0.7981 0.630 0.747
## 122 0.3199 0.7404 0.717 0.733
## 142 0.2699 0.6779 0.793 0.713
## 162 0.2221 0.6058 0.848 0.680
## 182 0.1675 0.5288 0.891 0.640
## 202 0.1375 0.4423 0.913 0.587
## 222 0.1165 0.3654 0.957 0.547
## 242 0.0869 0.2740 0.967 0.487
## 262 0.0626 0.1875 0.989 0.433
## 282 0.0420 0.0962 1.000 0.373
## 302 0.0000 0.0000 1.000 0.307

# The area under the curve is 0.812.  The higher the area under the curve, the less
# compromise is required in obtaining both high sensitivity and high specificity.
# The AUC can be interpreted as, the likelihood that the model will have assigned a 
# higher value to the positive sample, given a random selection of one member of the 
# positive group and another from the negative group

# Each point on this curve represents a combination of sensitivity (TPR) and 
# specificity (TNR) that can be achieved using various thresholds.
# We begin at the lower left with all points classified as FALSE (100% TNR) and none
# as TRUE (0% TPR).  We end at the right with the inverse - all TRUE, 100% TPR, 0% TNR.
# Thus you can see what your tradeoff's are in choosing a threshold on this model.
#
# E.g., in this case, if you are willing to accept a TPR of only 0.4, you can correctly
# identify the vast majority of negatives. But if you want to have a 90% TPR, you will
# only have ~50% of negatives classified correctly.


# Version 2 - Alternate method using pROC packkage
# Import the library for developing ROC curve
library(pROC)

# Develop ROC curve to determine the quality of fit
head(cbind(d.valid$V21,y_hat))   # see the data we are passing to ROC
roc.obj<-roc(d.valid$V21,y_hat)
roc.obj$auc

# Plot the ROC curve
plot.roc(roc.obj,main="ROC curve")

# To examine the available thresholds and the associated TPR (sensitivity), TNR
# (specificity), and accuracy, first, determine the prevalence (positive rate in our sample)
prev = sum(d.valid$V21)/length(d.valid$V21)

# From this, we calculate 
# accuracy = (sensitivity)(prevalence) + (specificity)(1 - prevalence)
acc = (roc.obj$sensitivities*prev) + (roc.obj$specificities*(1-prev))

# F1 is a popular metric combining Recall (aka Sensitivty aka TPR) and Precision (TP/(TP+FP))
#F1 = TP / (TP +(FP+FN)/2))
pop = length(y)   # total population
pos = length(y[y==1])       # number of positive values
neg = length(y[y==0])       # number of negative values
TP = pos * roc.obj$sensitivities
TPR = TP / pos
TN = neg * roc.obj$specificities
TNR = TN / neg
FN = pos * (1-TPR)
FP = neg * (1-TNR)
F1 = TP / (TP + ((FP+FN)/2))

# create a df of results from the roc object r we created earlier
res.df2 = data.frame(Thr=roc.obj$thresholds, Sens=roc.obj$sensitivities, Spec=roc.obj$specificities, Acc=acc, F1=F1)

# The full table is long, so we will just look at every 20th record
n = length(roc.obj$thresholds)
res.df2[seq(1, n, 20), ]

##        Thr  Sens   Spec   Acc
## 1     -Inf 1.000 0.0000 0.307
## 21  0.0438 1.000 0.0962 0.373
## 41  0.0640 0.989 0.1875 0.433
## 61  0.0877 0.967 0.2740 0.487
## 81  0.1166 0.957 0.3654 0.547
## 101 0.1376 0.913 0.4423 0.587
## 121 0.1679 0.891 0.5288 0.640
## 141 0.2228 0.848 0.6058 0.680
## 161 0.2719 0.793 0.6779 0.713
## 181 0.3216 0.717 0.7404 0.733
## 201 0.3795 0.630 0.7981 0.747
## 221 0.4689 0.533 0.8510 0.753
## 241 0.5516 0.457 0.9135 0.773
## 261 0.6165 0.348 0.9615 0.773
## 281 0.6994 0.196 0.9904 0.747
## 301    Inf 0.000 1.0000 0.693


# So if we're just looking for the highest accuracy, a threshold of 0.558 might suit.
# This would give a TPR of 45.7% and TNR of 92.3%

# We could plot the scores vs the threshold. 
plot(res.df2$Thr, res.df2$Sens, type='l', xlim=c(1.002,0), ylim=c(0,1.002), 
     yaxs="i", xaxs="i", col='blue', ylab='Score', xlab='Threshold')
lines(res.df2$Thr , res.df2$Spec, col='green')
lines(res.df2$Thr, res.df2$Acc, col='red')
lines(res.df2$Thr, res.df2$F1, col='orange')
legend('left', legend=c('TPR','TNR','Acc','F1'), col=c('blue','green','red','orange'),lty=1, bty='n')

# It can be seen that maximum Accuracy and maximum F1 are at quite different thresholds, so your
# choice of metric for choosing the best threshold can make qute a difference!

# This chart is perhaps intuitively easier to grasp, but 
# the ROC and AUC are more useful for overall evaluation of the regression as a binary classifier.


# -------------------- Part 2 -----------------------------

# Recall 1=bad customer and 0=good customer
# The loss of incorrectly classfying a "bad" customer (FN) is 5 times the loss of 
# incorrectly classifying a "good" customer (FP). 

# We have already calculated the TPR and TNR at each threshold
# Recall that FNR=1-TPR and FPR=1-TNR 
# So we can calculate the numbers of FP and FN directly from the data in res.df:
data.frame(Pos=pos, Neg=neg)
fn = (1-res.df$TPR)*pos
fp = (1-res.df$TNR)*neg
tcost = (fn*5) + fp
plot(res.df$Thr, tcost, xlab='Threshold', ylab='Cost', main="Cost vs Threshold", type='l')
f=which.min(tcost)
data.frame(MinCost=tcost[f],Thr=res.df$Thr[f])

# The threshold probability corresponding to minimum expected loss is 0.243  
# The range from 0.15-0.25 is all pretty good.
# The expected loss at 0.243 is 144 over the 300 validation data points.
# That compares to 260 for a threshold of 0.5.
# So accounting for the relative costs of misclassification is important!

# Here's the accuracy, TPR and TNR for the 0.243 threshold:
cbind(res.df, FN=fn, FP=fp, Cost=tcost)[f,]

